package br.com.fiap.endpoint.request;

public class TaxRequest {

}
