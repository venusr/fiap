package br.com.fiap.model;

public class Tax {
    private String name;
    private Double percent;
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getPercent() {
		return percent;
	}
	public void setPercent(Double percent) {
		this.percent = percent;
	}
    
    
    
}
