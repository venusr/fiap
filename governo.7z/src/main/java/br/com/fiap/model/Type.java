package br.com.fiap.model;

public enum Type {
	CPF,
	CNPJ
}
